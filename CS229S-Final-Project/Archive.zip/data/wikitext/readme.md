## Wikitext dataset

Running `prepare.py` (preprocess) will download the data from hugging face, tokenize it, and save it in bin files. These files will then be read in for training. 
